// data.js
export const Philosophers = [
  {
    id: 1,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 2,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 3,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 4,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 5,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 6,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 7,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
  {
    id: 8,
    name: "Marcus",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/cognition.png",
  },
];

export const Religious = [
  {
    id: 1,
    name: "Religious Person 2",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 2,
    name: "Religious Person 3",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 3,
    name: "Religious Person 4",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 4,
    name: "Religious Person 5",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 5,
    name: "Religious Person 6",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 6,
    name: "Religious Person 7",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 7,
    name: "Religious Person 8",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
  {
    id: 8,
    name: "Religious Person 9",
    description:
      "Marcus Aurelius Antoninus was Roman emperor from 161 to 180 and a Stoic philosopher",
    imageUrl: "./images/home/synagogue.svg",
  },
];
